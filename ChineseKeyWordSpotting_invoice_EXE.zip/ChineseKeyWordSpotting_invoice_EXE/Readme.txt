usage:
There are four input parameters in our keyword spotting function: 
the storage path of the input image; 
the storage path of the output fold ;
bool isUseRedChannel;
bool isSaveMedianResults.


Before using this executable program, you should make sure that the lexicon path is correct in the config file: .\TextDetection\WordDetectionConfig.txt


For the taxi invoice images, you may set the flag "isUseRedChannel = true"
KeyWordSpottingtest.exe taxi_0201.jpg .\\saveFold_taxi 1 0
KeyWordSpottingtest.exe taxi_0201.jpg .\\saveFold_taxi 1 1

For the vat invoice images, you may set the flag "isUseRedChannel = false"
KeyWordSpottingtest.exe vat_0053.jpg .\\saveFold_vat 0 0
KeyWordSpottingtest.exe vat_0053.jpg .\\saveFold_vat 0 1